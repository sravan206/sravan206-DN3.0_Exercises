package com.example.EmployeeManagementSystem.projection;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
