// Image.java
public interface Image {
    void display();
}
