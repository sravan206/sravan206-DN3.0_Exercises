// Logger.java
public class Logger {
    // Static instance of the Logger class
    private static Logger instance;

    // Private constructor to prevent instantiation from outside
    private Logger() {
        // Optional: Initialization code for logger instance
        System.out.println("Logger instance created.");
    }

    // Public static method to get the instance of Logger class
    public static Logger getInstance() {
        // Lazy initialization: create instance when accessed for the first time
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Example method for logging
    public void log(String message) {
        System.out.println("[LOG] " + message);
    }
}
