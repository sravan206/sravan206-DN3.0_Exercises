public class LinearSearch {
    public static Product linearSearch(Product[] products, int targetId) {
        for (Product product : products) {
            if (product.getProductId() == targetId) {
                return product;
            }
        }
        return null; // Not found
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Shampoo", "Health & Beauty"),
            new Product(3, "Coffee Maker", "Appliances"),
            new Product(4, "Smartphone", "Electronics")
        };

        int targetId = 3;
        Product result = linearSearch(products, targetId);
        if (result != null) {
            System.out.println("Found: " + result);
        } else {
            System.out.println("Product not found.");
        }
    }
}
